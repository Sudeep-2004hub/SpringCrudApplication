import React, { useEffect, useState } from 'react';

export default function Student() {
  // Tabs: 'single' or 'batch'
  const [activeTab, setActiveTab] = useState('single');
  
  // Single Student State
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  
  // Batch Students State
  const [batchStudents, setBatchStudents] = useState([{ name: '', address: '' }]);
  
  // Student List State
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  
  // Search ID State
  const [searchId, setSearchId] = useState('');
  const [searchResult, setSearchResult] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  // Edit Modal State
  const [editingStudent, setEditingStudent] = useState(null);
  const [editName, setEditName] = useState('');
  const [editAddress, setEditAddress] = useState('');

  // Toast Notifications State
  const [toasts, setToasts] = useState([]);

  // Delete ID input state
  const [deleteId, setDeleteId] = useState('');

  // Helper to show a Toast notification
  const showToast = (message, type = 'success') => {
    const id = Date.now();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 4000);
  };

  // Fetch all students
  const fetchAllStudents = () => {
    setLoading(true);
    fetch('http://localhost:8081/student/getAll')
      .then((res) => {
        if (!res.ok) throw new Error('Failed to fetch students.');
        return res.json();
      })
      .then((result) => {
        setStudents(result);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        showToast('Error loading students. Ensure the backend is running.', 'danger');
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchAllStudents();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Fetch student by ID
  const handleSearch = (e) => {
    e.preventDefault();
    if (!searchId.trim()) {
      setSearchResult(null);
      setHasSearched(false);
      fetchAllStudents();
      return;
    }

    setLoading(true);
    fetch(`http://localhost:8081/student/${searchId}`)
      .then((res) => {
        if (res.status === 404 || !res.ok) {
          throw new Error('Student not found');
        }
        // Check if response is empty
        return res.text().then(text => text ? JSON.parse(text) : null);
      })
      .then((data) => {
        if (data && data.id) {
          setSearchResult(data);
          showToast(`Found student: ${data.name}`);
        } else {
          setSearchResult(null);
          showToast(`No student found with ID: ${searchId}`, 'danger');
        }
        setHasSearched(true);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setSearchResult(null);
        setHasSearched(true);
        showToast(`No student found with ID: ${searchId}`, 'danger');
        setLoading(false);
      });
  };

  // Clear search results
  const clearSearch = () => {
    setSearchId('');
    setSearchResult(null);
    setHasSearched(false);
    fetchAllStudents();
  };

  // Add single student
  const handleAddSingle = (e) => {
    e.preventDefault();
    if (!name.trim() || !address.trim()) {
      showToast('Please fill out all fields.', 'danger');
      return;
    }

    const newStudent = { name, address };
    fetch('http://localhost:8081/student/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newStudent),
    })
      .then((res) => {
        if (!res.ok) throw new Error('Add student failed');
        return res.text();
      })
      .then((msg) => {
        showToast(msg || 'Student added successfully!');
        setName('');
        setAddress('');
        fetchAllStudents();
      })
      .catch((err) => {
        console.error(err);
        showToast('Failed to add student.', 'danger');
      });
  };

  // Handle batch input changes
  const handleBatchChange = (index, field, value) => {
    const updated = [...batchStudents];
    updated[index][field] = value;
    setBatchStudents(updated);
  };

  // Add dynamic row for batch add
  const addBatchRow = () => {
    setBatchStudents([...batchStudents, { name: '', address: '' }]);
  };

  // Remove dynamic row for batch add
  const removeBatchRow = (index) => {
    if (batchStudents.length === 1) return;
    setBatchStudents(batchStudents.filter((_, i) => i !== index));
  };

  // Batch Save (Save All)
  const handleAddBatch = (e) => {
    e.preventDefault();
    const validBatch = batchStudents.filter(
      (s) => s.name.trim() !== '' && s.address.trim() !== ''
    );

    if (validBatch.length === 0) {
      showToast('Please enter at least one complete student details.', 'danger');
      return;
    }

    fetch('http://localhost:8081/student/addAll', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(validBatch),
    })
      .then((res) => {
        if (!res.ok) throw new Error('Batch save failed');
        return res.text();
      })
      .then((msg) => {
        showToast(msg || `Batch of ${validBatch.length} students added!`);
        setBatchStudents([{ name: '', address: '' }]);
        fetchAllStudents();
      })
      .catch((err) => {
        console.error(err);
        showToast('Failed to save batch.', 'danger');
      });
  };

  // Delete student by ID
  const handleDelete = (id) => {
    if (!window.confirm(`Are you sure you want to delete student with ID ${id}?`)) {
      return;
    }

    fetch(`http://localhost:8081/student/delete/${id}`, {
      method: 'DELETE',
    })
      .then((res) => {
        if (!res.ok) throw new Error('Delete failed');
        return res.text();
      })
      .then((msg) => {
        showToast(msg || 'Student deleted.');
        // If we currently have a search result displayed, clear it
        if (searchResult && searchResult.id === id) {
          clearSearch();
        } else {
          fetchAllStudents();
        }
      })
      .catch((err) => {
        console.error(err);
        showToast('Failed to delete student.', 'danger');
      });
  };

  // Delete all students
  const handleDeleteAll = () => {
    if (
      !window.confirm(
        'WARNING: This will delete ALL student records in the system. Are you absolutely sure?'
      )
    ) {
      return;
    }

    fetch('http://localhost:8081/student/deleteAll', {
      method: 'DELETE',
    })
      .then((res) => {
        if (!res.ok) throw new Error('Delete all failed');
        return res.text();
      })
      .then((msg) => {
        showToast(msg || 'All student records deleted successfully.');
        clearSearch();
      })
      .catch((err) => {
        console.error(err);
        showToast('Failed to delete all student records.', 'danger');
      });
  };

  // Delete student by ID input form handler
  const handleDeleteByIdInput = (e) => {
    e.preventDefault();
    if (!deleteId.trim()) {
      showToast('Please enter a student ID.', 'danger');
      return;
    }
    handleDelete(deleteId);
    setDeleteId('');
  };

  // Open Edit Modal
  const openEditModal = (student) => {
    setEditingStudent(student);
    setEditName(student.name);
    setEditAddress(student.address);
  };

  // Close Edit Modal
  const closeEditModal = () => {
    setEditingStudent(null);
    setEditName('');
    setEditAddress('');
  };

  // Update student details
  const handleUpdate = (e) => {
    e.preventDefault();
    if (!editName.trim() || !editAddress.trim()) {
      showToast('Name and Address fields cannot be empty.', 'danger');
      return;
    }

    const updatedData = { name: editName, address: editAddress };
    fetch(`http://localhost:8081/student/update/${editingStudent.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedData),
    })
      .then((res) => {
        if (!res.ok) throw new Error('Update failed');
        return res.text();
      })
      .then((msg) => {
        showToast(msg || 'Student updated successfully!');
        closeEditModal();
        // Update display data
        if (searchResult && searchResult.id === editingStudent.id) {
          setSearchResult({ ...searchResult, ...updatedData });
        } else {
          fetchAllStudents();
        }
      })
      .catch((err) => {
        console.error(err);
        showToast('Failed to update student.', 'danger');
      });
  };

  // Determine list of students to render
  const displayedStudents = searchResult ? [searchResult] : students;

  return (
    <div className="container">
      {/* Toast Notification Box */}
      <div className="toast-container">
        {toasts.map((toast) => (
          <div key={toast.id} className={`toast ${toast.type}`}>
            <span>{toast.message}</span>
            <button className="toast-close" onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}>
              &times;
            </button>
          </div>
        ))}
      </div>

      {/* Main Grid Layout */}
      <div className="dashboard-grid">
        
        {/* Left Column: Management / CRUD Input Panels */}
        <div>
          <div className="glass-card" style={{ marginBottom: '24px' }}>
            <div className="tab-container">
              <button className={`tab-btn ${activeTab === 'single' ? 'active' : ''}`} onClick={() => setActiveTab('single')}>
                Add Student
              </button>
              <button className={`tab-btn ${activeTab === 'batch' ? 'active' : ''}`} onClick={() => setActiveTab('batch')}>
                Batch Add (Save All)
              </button>
            </div>

            {activeTab === 'single' ? (
              <form onSubmit={handleAddSingle}>
                <h2>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}>
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="16" y1="11" x2="22" y2="11"/>
                  </svg>
                  <span>Student Details</span>
                </h2>
                
                <div className="form-group">
                  <label className="form-label">Full Name</label>
                  <input type="text" className="form-input" value={name} onChange={(e) => setName(e.target.value)} required />
                </div>

                <div className="form-group">
                  <label className="form-label">Address</label>
                  <input type="text" className="form-input" value={address} onChange={(e) => setAddress(e.target.value)} required />
                </div>

                <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
                  Submit Record
                </button>
              </form>
            ) : (
              <form onSubmit={handleAddBatch}>
                <h2>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}>
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                  </svg>
                  <span>Batch Registration</span>
                </h2>

                {batchStudents.map((student, idx) => (
                  <div key={idx} className="dynamic-row">
                    <input type="text" className="form-input" value={student.name} onChange={(e) => handleBatchChange(idx, 'name', e.target.value)} required />
                    <input type="text" className="form-input" value={student.address} onChange={(e) => handleBatchChange(idx, 'address', e.target.value)} required />
                    <button type="button" className="btn-icon delete" onClick={() => removeBatchRow(idx)} disabled={batchStudents.length === 1} title="Remove row">
                      &times;
                    </button>
                  </div>
                ))}

                <div style={{ display: 'flex', gap: '10px', marginTop: '16px' }}>
                  <button type="button" className="btn btn-outline" style={{ flex: 1 }} onClick={addBatchRow}>
                    + Add Row
                  </button>
                  <button type="submit" className="btn btn-secondary" style={{ flex: 1.5 }}>
                    Save All
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Quick Actions & Statistics Panel */}
          <div className="glass-card">
            <h2>System Control Panel</h2>
            <p style={{ color: 'var(--text-secondary)', fontSize: '14px', marginBottom: '16px' }}>
              Perform administration actions across all records in the local storage database.
            </p>
            
            <form onSubmit={handleDeleteByIdInput} style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
              <input type="number" className="form-input" placeholder="Delete by ID (e.g. 5)" value={deleteId} onChange={(e) => setDeleteId(e.target.value)} required />
              <button type="submit" className="btn btn-danger" style={{ padding: '0 16px', fontSize: '13px', whiteSpace: 'nowrap' }}>
                Delete ID
              </button>
            </form>

            <button className="btn btn-danger" style={{ width: '100%', background: 'transparent', border: '1px solid var(--danger)', color: 'var(--danger)' }} onClick={handleDeleteAll} disabled={students.length === 0 && !searchResult}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>
              </svg>
              Delete All Records
            </button>
          </div>
        </div>

        {/* Right Column: Database Records Grid */}
        <div className="glass-card">
          {/* Search by ID form */}
          <form onSubmit={handleSearch} className="search-container">
            <input type="number" className="form-input search-input" placeholder="Search / Fetch by ID (e.g. 5)" value={searchId} onChange={(e) => setSearchId(e.target.value)} />
            <button type="submit" className="btn btn-primary" style={{ padding: '0 20px' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
              </svg>
              Search
            </button>
            {hasSearched && (
              <button type="button" className="btn btn-outline" onClick={clearSearch}>
                Clear
              </button>
            )}
          </form>

          <h2>
            <span>Student Directory</span>
            <span style={{ fontSize: '14px', padding: '4px 10px', background: 'rgba(255,255,255,0.06)', borderRadius: '12px', color: 'var(--text-secondary)' }}>
              {students.length} Total
            </span>
          </h2>

          {loading ? (
            <div className="empty-state">
              <div className="loader" style={{ border: '3px solid rgba(255,255,255,0.1)', borderTop: '3px solid var(--primary)', borderRadius: '50%', width: '30px', height: '30px', animation: 'spin 1s linear infinite' }} />
              <p>Fetching records...</p>
              <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
            </div>
          ) : displayedStudents.length === 0 ? (
            <div className="empty-state">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="18" y1="8" x2="18" y2="14"/><line x1="15" y1="11" x2="21" y2="11"/>
              </svg>
              <h3>No Records Found</h3>
              <p>Add some students on the left or change the filter query to begin.</p>
            </div>
          ) : (
            <div className="student-list-container">
              {displayedStudents.map((student) => (
                <div key={student.id} className="student-card">
                  <div className="student-info">
                    <span style={{ fontSize: '11px', color: 'var(--primary)', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '1px' }}>
                      ID: #{student.id}
                    </span>
                    <h3>{student.name}</h3>
                    <p style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>
                      </svg>
                      {student.address}
                    </p>
                  </div>
                  <div className="student-actions">
                    <button className="btn-icon edit" onClick={() => openEditModal(student)} title="Edit Student">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>
                      </svg>
                    </button>
                    <button className="btn-icon delete" onClick={() => handleDelete(student.id)} title="Delete Student">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Edit Student Modal Overlay */}
      <div className={`modal-overlay ${editingStudent ? 'active' : ''}`} onClick={closeEditModal}>
        <div className="modal-content glass-card" onClick={(e) => e.stopPropagation()}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h2>Edit Student Details</h2>
            <button className="btn-icon" onClick={closeEditModal} style={{ fontSize: '20px' }}>&times;</button>
          </div>
          
          <form onSubmit={handleUpdate}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input type="text" className="form-input" value={editName} onChange={(e) => setEditName(e.target.value)} required />
            </div>

            <div className="form-group">
              <label className="form-label">Address</label>
              <input type="text" className="form-input" value={editAddress} onChange={(e) => setEditAddress(e.target.value)} required />
            </div>

            <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
              <button type="button" className="btn btn-outline" style={{ flex: 1 }} onClick={closeEditModal}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" style={{ flex: 1.5 }}>
                Save Changes
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
