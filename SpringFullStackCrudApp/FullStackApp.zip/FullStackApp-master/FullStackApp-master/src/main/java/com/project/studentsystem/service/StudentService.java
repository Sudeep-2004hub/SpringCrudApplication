package com.project.studentsystem.service;

import java.util.List;

import com.project.studentsystem.model.Student;

public interface StudentService {
    public Student saveStudent(Student student);
    public List<Student> getAllStudents();
    public Student getStudentById(int id);
    public String deleteStudent(int id);
    public String deleteAllStudents();
    public List<Student> saveAllStudents(List<Student> students);
    public Student updateStudent(int id, Student student);
}
