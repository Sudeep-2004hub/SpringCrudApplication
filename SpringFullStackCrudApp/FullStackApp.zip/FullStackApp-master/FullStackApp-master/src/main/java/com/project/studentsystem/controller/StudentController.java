package com.project.studentsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.project.studentsystem.model.Student;
import com.project.studentsystem.service.StudentService;

import java.util.List;

@RestController
@RequestMapping("/student")
@CrossOrigin
public class StudentController {
    @Autowired
    private StudentService studentService;

    @PostMapping("/add")
    public String add(@RequestBody Student student){
        studentService.saveStudent(student);
        return "New student is added";
    }

    @GetMapping("/getAll")
    public List<Student> list(){
        return studentService.getAllStudents();
    }

    @GetMapping("/{id}")
    public Student getById(@PathVariable int id){
        return studentService.getStudentById(id);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable int id){
        return studentService.deleteStudent(id);
    }

    @DeleteMapping("/deleteAll")
    public String deleteAll(){
        return studentService.deleteAllStudents();
    }

    @PostMapping("/addAll")
    public String addAll(@RequestBody List<Student> students){
        studentService.saveAllStudents(students);
        return "All students are added";
    }

    @PutMapping("/update/{id}")
    public String update(@PathVariable int id, @RequestBody Student student){
        Student updated = studentService.updateStudent(id, student);
        if(updated != null) {
            return "Student is updated successfully";
        }
        return "Student with ID " + id + " does not exist";
    }
}
